/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biodata;

/**
 *
 * @author ASUS
 */
public class Biodata {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    String Nama="ANENDA OCTAVIA SALSA BILLA";
    String jk="PEREMPUAN";
    String alamat="DESA GERBO";
    String jurusan="REKAYASA PERANGKAT LUNAK";

    System.out.println("BIODATA DIRI");
    System.out.println("--------");
    System.out.println("Nama \t\t\t\t :"+Nama);
    System.out.println("Jenis kelamin \t\t :"+jk);
    System.out.println("Alamat \t\t\t\t :"+alamat);
    System.out.println("Jurusan \t\t :"+jurusan);
    
    
}
    
    }
    
}
