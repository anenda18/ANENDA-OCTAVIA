package class=tutorial;
public class main {
    public static void main(string[]args)
    String Nama="ANENDA OCTAVIA SALSA BILLA";
    String jk="PEREMPUAN";
    String alamat="DESA GERBO";
    String jurusan="REKAYASA PERANGKAT LUNAK";

    System.out.println("BIODATA DIRI");
    System.out.println("Nama \t\t\t\t :"+nama);
    System.out.println("Jenis kelamin \t\t :"+jk);
    System.out.println("Alamat \t\t\t\t :"+alamat);ss
    System.out.println("Jurusan \t\t\t :"+jurusan);
    
    
}